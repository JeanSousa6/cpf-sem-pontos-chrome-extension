# Extensão Chrome de Retirar Pontuação de CPFs Válidos

* Ferramenta simples para auxiliar em buscas e projetos em que precisa validar e retirar a pontuação cpf

### Funcionalidades

* Retira a pontuação

*  Exemplo : 111.444.777-35 
retorna 1114447735

* Inteface Simples Exemplo

![Interface](source/cpf_cleaner_resized_640x400.png)





